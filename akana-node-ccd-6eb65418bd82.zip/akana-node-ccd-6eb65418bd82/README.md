# node-ccd
## An API for HL7 CCD use case

### Background

See more information at the [repo wiki](https://bitbucket.org/akana/node-ccd/wiki/Home)

## Install and Run

* Clone repo
* `cd node-ccd\server`
* Get supporting libs: `npm install`
* Run: `node app.js`

## SoaMobileDemo

Used to demonstrate SOA product capabilities that enable enterprise 
mobile application development. This demo is implemented using the 
Sencha Touch 2.2.1 framework and Sencha Architect 2.
