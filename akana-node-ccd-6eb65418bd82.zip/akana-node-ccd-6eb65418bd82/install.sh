#!/bin/sh
cd server
npm install
node app.js

