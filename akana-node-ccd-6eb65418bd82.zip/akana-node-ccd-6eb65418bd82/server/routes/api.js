var jsonpath = require('JSONPath');
var Url = require('url');
var fs = require('fs');
var path = require('path');

var dummydata = undefined;
var cptcodes = undefined;
var log = undefined;

var errorResult = { "error": { "code": 404, "message": "record not found"} };
var errorResultLength = JSON.stringify(errorResult).length;

exports.setLog = function(data) {
  log = data;
}

exports.setDummydata = function(data) {
  dummydata = data;
  console.log("Data set: " + JSON.stringify(data).length);
}

function readInData(callback) {
  // read in dummy data
  fs.readFile(path.join(__dirname, '../data/ccd-0.json'), 'utf8', 
  function (err, data) {
    if (err) throw err;
    dummydata = JSON.parse(data);
    log.debug("Read in data " + data.length);
    callback(dummydata);
  });
};

function readInCptCodes(callback) {
  fs.readFile(path.join(__dirname, '../data/cptcodes.json'), 'utf8',
  function(err, data) {
    if (err) throw err;
    cptcodes = JSON.parse(data);
    callback(cptcodes);
  });
}

function findCptCodeById(id, callback, errorCallback) {
  log.debug('findCptCodeById');
  var cptcode = { "error": "no cpt code found" };

  readInCptCodes(function(codes) {
     var cpts = codes.cptCodes;
     cpts.forEach(function(cpt) {     
       if (id.toString() === cpt.cptCode) {
         callback(cpt);
         return;
       }
     });
     callback(cptcode);
  });
}

exports.getCptCodes = function(req, res) {
  readInCptCodes(function(codes) {
    res.json(codes.cptCodes);
  });
}

exports.getCptCode = function(req, res) {
  var id = req.params.id;
  findCptCodeById(id, function(result) {
    res.json(result);
  }, null);  
}

// terrible search that should be rewritten
function findPatientByMrn(mrn, callback, errorCallback) {
  log.debug('findPatientByMrn');
  var patient = { "error": "no patient found" };
  
  readInData(function(dummydata) { 
    log.debug("Data size: " + dummydata.length);

    for (var i = 0; i < dummydata.length; i++) {
      var currentMrn = JSON.stringify(dummydata[i].mrn);
      log.debug(" ... looking at " + currentMrn);
      if (mrn === currentMrn) {
        patient = dummydata[i];
        log.debug("Patient found: " + patient.mrn);
        log.debug("  size: " + JSON.stringify(patient).length);
        if (callback) {
          callback(patient);
          return;
        } else {
          return patient;
        }
      }
    }

    if (errorCallback) {
      errorCallback(patient);
      return;
    } else {
      return patient;
    }
  });
}

// add the id to each item in the array
function addMrn(arr, mrn, callback) {
  arr.forEach(function(a) {
     a.mrn = mrn;
  });
  if (callback) {
    callback(arr);
  } else {
    return arr;
  }
}

/** json api **/
exports.listPatients = function(req, res) {
  var result = [];

  for (var i = 0; i < dummydata.length; i++) {
    var p = dummydata[i];
    result.push( { "mrn": p.mrn, "firstName": p.firstName, "lastName": p.lastName });
  }
  
  log.debug(req.connection.remoteAddress + ' listPatients: ' 
	+ JSON.stringify(result).length);
  res.json(result);
};


// GET limited set of patient data
exports.getPatient = function(req, res) {
  log.debug('getPatient');
  var result = { 'mrn': req.params.id }; 
  
 //findPatientByMrn(dummydata, req.params.id, function(patient) {
  findPatientByMrn(req.params.id, function(patient) {
    delete patient.insurers;
    delete patient.visits;
    delete patient.problems;
    delete patient.allergies;
    delete patient.medications;
    delete patient.diagnosticResults;
    delete patient.procedures;
    result = patient;
  
    log.debug(req.connection.remoteAddress + ' getPatient ' + req.params.id + ": " 
  	+ JSON.stringify(result).length);
    res.json(result);
  });

};

// find specifics about patient
exports.getPatientInfo = function(req, res) {
  var result = errorResult;
  result.mrn = req.params.id; // queuing up the error

  var parts = Url.parse(req.url, true);
  //var part = (parts.pathname).split('/').slice(-1)[0];
  var part = req.params.part;
  if (part === 'results') part = 'diagnosticResults';

  findPatientByMrn(req.params.id, 
    function(patient) {
      log.debug("getPatientInfo - looking for " + part);
      log.debug("  patient size: " + JSON.stringify(patient).length);

      // now that we have a patient
      //if (part in patient) {
      if (patient.hasOwnProperty(part)) {
        log.debug("Found part...");
        log.debug("found " + part + " for " + patient.mrn);

        addMrn(patient[part], patient.mrn, function(result) {
	  res.json(result);
          log.debug(req.connection.remoteAddress + " " + part + " for " 
            + req.params.id +  ": "
            + JSON.stringify(result).length + " "
            + parts.pathname + " " + JSON.stringify(parts.query));
        });
      } else { // redundancy in logging could be corrected
        log.warning("Did not find part...");
        log.warning(JSON.stringify(patient));
        result.error.message = part + " not found";
        res.status(404);
        res.json(result);
        log.err(req.connection.remoteAddress + " " + part + " for " + req.params.id +  ": " 
          + JSON.stringify(result).length + " " + parts.pathname + " " + JSON.stringify(parts.query));
      } 
    });
};

// testing jsonpath
exports.getPatientPath = function(req,res) {
  var result = { 'mrn': req.params.id };
  
  for (var i = 0; i < dummydata.length; i++) {
    if (req.params.id === JSON.stringify(dummydata[i].mrn)) {
      result = jsonpath.eval(dummydata[i], '$..')[0];
    }
  }

  log.debug(JSON.stringify(result).length);
  res.json(result);
};

