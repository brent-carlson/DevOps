var express = require('express'),
    routes = require('./routes'),
    api = require('./routes/api');
var http = require('http');
var path = require('path');
var config = require('./config.json');
var logentries = require('node-logentries');

var subpath = require('express'); // for Swagger

var log = logentries.logger({token: config.LOGENTRIES_TOKEN});
api.setLog(log);

var allowCrossDomain = function(req, res, next) {
  if (req.headers.hasOwnProperty("origin")) {
    if (config.allowedDomains.indexOf("*") > -1 || config.allowedDomains.indexOf(req.headers["origin"]) > -1) {
      res.header('Access-Control-Allow-Origin', req.headers["origin"]);
      res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
      res.header('Access-Control-Allow-Headers', 'Content-Type');
      res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    } else {
      log.warning("CORS Denied for " + req.headers["origin"]);
    }
  }
  next();
};

var app = module.exports = express();

app.set('port', process.env.PORT || config.PORT);
app.set('views', __dirname + "/views");
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.bodyParser());
app.use(express.logger('dev'));
app.use(express.methodOverride());
app.use(allowCrossDomain);
app.use(app.router);
app.use(express.static(path.join(__dirname, '/public')));

app.use('/v1', subpath);

// read in dummy data
var fs = require('fs');
var dummydata;
fs.readFile(path.join(__dirname, '/data/ccd-0.json'), 'utf8', function (err, data) {
  if (err) throw err;
  dummydata = JSON.parse(data);
  app.set('dummydata', dummydata);
  api.setDummydata(dummydata);
});
//dummydata = api.readData;
//app.set('dummydata', dummydata);

// testing only
if ('testing' === app.get('env')) {
  app.use(express.errorHandler());
  app.set('port', 3000);
}
// production env
if ('production' === app.get('env')) {
  // something else
}

// web
app.get('/', routes.index);

// API
app.options("*", function(req,res,next){ res.send(200); });
// global controller
app.get('/*',function(req,res,next){
    res.header('Version' , config.VERSION );
    next(); // http://expressjs.com/guide.html#passing-route control
});

app.get('/api/patients', api.listPatients);
app.get('/api/patient/:id/:part', api.getPatientInfo);
app.get('/api/patient/:id', api.getPatient);
app.get('/api/cptcodes', api.getCptCodes);
app.get('/api/cptcode/:id', api.getCptCode);
// test
app.get('/api/path/:id', api.getPatientPath);

http.createServer(app).listen(app.get('port'), function() {
 console.log("Express server listening at " + app.get('port'));
});

