var http = require('http');
var should = require('should');

var sessionCookie = null;

// app to test
var app = require(__dirname + '/../app.js');
app.set('env', 'testing'); // app knows to set port to 3000
var port = 3000;

// TEST SUITE: app
// start the app, verify it's up
describe('app', function() {
  /*
  before(function(done) {
    app.listen(app.get('port'), function(err, result) {
      if (err) {
        done(err);
      } else {
        done();
      }
    });
  });
               
  after(function(done) {
    app.close();
   });
  */
  
  it('should exist', function(done) {
    should.exist(app);
    done();
  });
    
  it('should be listening at ' + app.get('port'), function(done) {
    var headers = defaultGetOptions('/');
    http.get(headers, function(res) {
      res.statusCode.should.eql(200);
      done();
    });
  });
  
});

function defaultGetOptions(path) {
  var options = {
    "host:": "http://api-box-20637.usw1.actionbox.io/",
    "port": port,
    "path": path,
    "method": "GET",
    "headers": {
      "Cookie": sessionCookie
    }
  };
  return options;
}