

var currentEventId = '';
var currentToken = '';
var authView;

// local dev service endpoint
//var cfnBaseApiPath = 'http://localhost:4000/api';

// virtual service endpoint
//var cfnBaseApiPath = 'http://patient.demo.soa.local:9901/emr';

// physical service endpoint
var cfnBaseApiPath = 'http://ec2-54-234-107-53.compute-1.amazonaws.com:4000/api';


var logoutButton = null;

function getURLData(url) {
  var json = loadSyncRequest(url, "application/json");
  return JSON.parse(json);
}




function loadSyncWithoutAuthRequest(url, mimeType)
{
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.open("GET",url,false);
  if (mimeType !== null) {
    if (xmlhttp.overrideMimeType) {
      xmlhttp.overrideMimeType(mimeType);
    }
  }
  try 
  {
      xmlhttp.send();
  }
    catch(err) {
        if (err.code == 19)
        	return 0; // no connection
    }
      
      
  if (xmlhttp.status==401) // login failure, invalid usr/pwd/event set
  {
  	return '401';
  }
 
  if (xmlhttp.status==200)
  {
    return xmlhttp.responseText;
  }
  else {
    return null;
  }
}





function loadSyncRequest(url, mimeType)
{
  
  var xmlhttp=new XMLHttpRequest();
    
    
  xmlhttp.open("GET",url,false);
    
  if (mimeType !== null) {
    if (xmlhttp.overrideMimeType) {
      xmlhttp.overrideMimeType(mimeType);
    }
  }
  try 
  {
      xmlhttp.send();
  }
    catch(err) {
        if (err.code == 19)
        	return 0; // no connection
    }
      
  if (xmlhttp.status==200)
  {
    return xmlhttp.responseText;
  }
  else {
    return null;
  }
}






function loadAyncRequest(url, mimeType, modelType)
{
  var currentToken = localStorage.getItem("cwlogintoken");  
  var xmlhttp=new XMLHttpRequest();
    
  xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    	xmlhttp.responseText;
    }
  }
  
  xmlhttp.open("GET",url,true);
  xmlhttp.setRequestHeader('AuthToken',currentToken);
    
  if (mimeType !== null) {
    if (xmlhttp.overrideMimeType) {
      xmlhttp.overrideMimeType(mimeType);
    }
  }
  try 
  {
      xmlhttp.send();
  }
    catch(err) {
        if (err.code == 19)
        	return 0; // no connection
    }
      
      
  if (xmlhttp.status==401) // login failure, invalid usr/pwd/event set
  {
  	return '401';
  }
 
  if (xmlhttp.status==200)
  {
    return xmlhttp.responseText;
  }
  else {
    return null;
  }
}

