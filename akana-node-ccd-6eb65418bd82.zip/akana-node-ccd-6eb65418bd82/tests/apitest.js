
//var apiBasePath = 'http://api-box-20637.usw1.actionbox.io:4000/api';
//var apiBasePath = 'http://apis.bespokesystems.net:4000/api';
var apiBasePath = 'http://localhost:4000/api';
var sanityCheckURL = 'http://freegeoip.net/json/210.120.10.10';

// Set up API endpoints to call
var apiRoute1 = '/patients';
var apiRoute2 = '/patient/309854081';
var apiRoute3 = '/patient/309854081/visits';
var apiRoute4 = '/patient/309854081/problems';
var apiRoute5 = '/patient/309854081/medications';
var apiRoute6 = '/patient/309854081/procedures';
var apiRoute7 = '/patient/309854081/allergies';
var apiRoute8 = '/patient/309854081/visits';
var apiRoute9 = '/patient/309854081/insurers';
var apiRoute10 = '/patient/309854081/results';
var apiRoutes = [apiRoute1, apiRoute2, apiRoute3, apiRoute4, apiRoute5, apiRoute5, apiRoute6, apiRoute7, apiRoute8, apiRoute9, apiRoute10];

var resultsElement = document.getElementById('results');
var useAlerts = false;
var abort = false;

// override window.alert to push to console
function alert(msg) {
	console.log(msg);
	if (useAlerts) {
		if (!window.confirm(msg)) {
			// abort
			abort = true;
		}
	}
	resultsElement.textContent += msg + "\n";
}

function runTest() {

	abort = false;
	resultsElement.textContent = ""; // clear results div
	useAlerts = document.getElementById('alerts').checked; // determine whether window alerts should be used

	alert('Test Start');

	// do before: sanity check; this call should always work...
	getURLDataSynchronously(sanityCheckURL, false);
	getURLDataAsynchronously(sanityCheckURL, false);

	// make synchronous API calls
	for (var i = 0; i < apiRoutes.length ; i++) {
		syncReturnData = getURLDataSynchronously(apiRoutes[i], true);
	}

	// make asynchronous API calls
	for (i = 0; i < apiRoutes.length; i++) {
		syncReturnData = getURLDataAsynchronously(apiRoutes[i], true);
	}

	// do after: sanity check; this call should always work...
	getURLDataSynchronously(sanityCheckURL, false);
	getURLDataAsynchronously(sanityCheckURL, false);

}

// ASYNCHRONOUS CALL.....
function getURLDataAsynchronously(restRouteSpec, useBaseUrl) {

    var xmlHttpReq = new XMLHttpRequest();
    var requestUrl;

    if (useBaseUrl)
		requestUrl = apiBasePath + restRouteSpec; // '/patients  or '/patient/002020  or '/patient/0202020/view';
    else
		requestUrl = restRouteSpec;

	alert('calling URL asynchronously: ' + requestUrl);

    xmlHttpReq.overrideMimeType("application/json");
    xmlHttpReq.onreadystatechange = function() {
        if (xmlHttpReq.readyState == 4 && xmlHttpReq.status == 200 ) {
            console.log(xmlHttpReq.responseText);
            alert('xmlHttpReq.responseText: ' + xmlHttpReq.responseText);
            alert(' success on async req: <' + requestUrl + '> ' + xmlHttpReq.responseText );
        }
        if (xmlHttpReq.readyState == 4 && xmlHttpReq.status != 200 ) {
            console.log(xmlHttpReq.responseText);
            alert('ReadyState: ' + xmlHttpReq.readyState);
            alert('httpStatus: ' + xmlHttpReq.status);
		}
    }; // end callback

	try {
		xmlHttpReq.open('GET', requestUrl, true);
		xmlHttpReq.send();
	}
	catch(err) {
		if (err.code == 19) {
			alert('cannot connect to ' + requestUrl);
			return 0; // no connection
		} else {
			alert('exeption on ' + requestUrl);
		}
	}
}

// SYNCHRONOUS CALLS.....
function getURLDataSynchronously( restRouteSpec, useBaseUrl ) {

	var json;
	var requestUrl;

    if (useBaseUrl)
		requestUrl = apiBasePath + restRouteSpec;   // '/patients  or '/patient/002020  or '/patient/0202020/view';
    else
		requestUrl = restRouteSpec;

	alert('calling URL synchronously: ' + requestUrl);
	json = loadSyncRequest(requestUrl, "application/json");

	return JSON.parse(json);
}

function loadSyncRequest(url, mimeType)
{
  var xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.open("GET",url,false);
  xmlHttpReq.overrideMimeType(mimeType);

  try
  {
	xmlHttpReq.send();
  }
  catch(err) {
	if (err.code === 19) {
		alert('cannot connect to ' + url);
		return 0; // no connection
	}
  }

  if (xmlHttpReq.status === 200)
  {
	alert('success on sync req: <' + url + '> ' + xmlHttpReq.responseText);
	return xmlHttpReq.responseText;
  }
  else { // any readyState any status
	alert('error on sync req: <' + url + '> ' + xmlHttpReq.responseText);
	return null;
  }
}